

rm(list=ls())

options(warn=-1)

require(MASS)
require(mvtnorm)
require(randomForest)
require(caret)
require(e1071)
require(zeallot)
require(ggplot2)
require(forcats)
require(mvnfast)
require(nnet)
require(survival)
require(survminer)
require(lubridate)
require(fastDummies)
require(gtools)
require(plm)
require(Rcpp)
require(DescTools)

options(error=recover)

source("sourceAll.R")
path = getwd()
except.v = c("main.R","stage-1.R", "optimize.R")
except.v = c(except.v, "preStage-1.R", "preamble.R")

sourceDir(path, except=except.v)
