#####################################
# The following R packages are 
# necessary for running this code:
#####################################
# MASS, mvtnorm, randomForest, caret, 
# e1071, zeallot, ggplot2, forcats, 
# mvnfast, nnet, survival, survminer, 
# lubridate, fastDummies, gtools, plm, Rcpp, 
# DescTools
#####################################

source("preamble.R")

num.random = 5

load("example_data.RData")

fixed.beta.z = c(80,10)
fixed.beta.z = fixed.beta.z/sum(fixed.beta.z)

data <- formatData(input) 

tmp = fn.Estimate_mgPS(input, data)
parm = tmp[[1]]
data = tmp[[2]]

source("optimize.R")


print(percentESS_methods)

