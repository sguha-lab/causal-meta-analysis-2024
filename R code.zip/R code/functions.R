fn.rdirichlet <- function(alpha)
{
  
  vec = rgamma(n=length(alpha), shape=alpha, rate=1)
  vec/sum(vec)
  
}




fn.SVD <- function(data, cutoff)
  {
    
    matX = data.matrix(data$flat$X)
    SVD = svd(matX); eigen.v = SVD$d
    maxx= min(which(cumsum(eigen.v)/sum(eigen.v)>cutoff))
    matX2 = SVD$u[,1:maxx] %*% diag(SVD$d[1:maxx]) %*% t(SVD$v[,1:maxx])
    cor(as.vector(matX), as.vector(matX2))
    
    matX2
  }


fn.RF_ZFirst <- function(data, svdCutoff=.5)
{
  parm = NULL

  parm$e$z = array(,c(data$N, data$K))
  
  df = data.frame(cbind(data$flat$Z, data$flat$X))
  names(df) = c("Z", paste("X", 1:data$p, sep=""))
  
  matX2 = fn.SVD(data, cutoff=svdCutoff)
  cor(as.vector(data.matrix(data$flat$X)), as.vector(matX2))
  
  df = data.frame(cbind(data$flat$Z, matX2))
  names(df) = c("Z", paste("X", 1:data$p, sep=""))
  
  tmp1 = randomForest(as.factor(Z)~., data=df)
  
  parm$rf_z = tmp1
  
  parm$e$z = tmp1$votes
  
  confusionMatrix(data=as.factor(apply(parm$e$z,1,which.max)), reference=data$flat$Z)
  apply(parm$e$z,2,summary)
  
  
  parm$rf_sGiven_z = rep(list(NA), data$K)
  
  parm$e$sGiven_z = array(0,c(data$N, data$J, data$K))
  
  
  for (z in 1:data$K)
    {indx.z = which(data$flat$Z == z)
      
    df = data.frame(cbind(data$flat$S[indx.z], matX2[indx.z,]))
    names(df) = c("S", paste("X", 1:data$p, sep=""))
    
    tmp1 = randomForest(as.factor(S)~., data=df, xtest=data.frame(data$flat$X[-indx.z,]))
    
    parm$rf_sGiven_z[[z]] = tmp1
    
    cols = as.numeric(dimnames(tmp1$test$votes)[[2]])
    
    tmp1$votes[which(!is.finite(tmp1$votes))] = 1/length(cols)
    tmp1$test$votes[which(!is.finite(tmp1$test$votes))] = 1/length(cols)
    
    parm$e$sGiven_z[-indx.z,cols,z] = tmp1$test$votes
    parm$e$sGiven_z[indx.z,cols,z] = tmp1$votes
    
    parm$e$sGiven_z[,,z] = parm$e$sGiven_z[,,z]/rowSums(parm$e$sGiven_z[,,z])
    
    unique(apply(parm$e$sGiven_z[,,z],1,sum))
    
    confusionMatrix(data=as.factor(apply(parm$e$sGiven_z[indx.z,,z],1,which.max)), reference=data$flat$S[indx.z])
    apply(parm$e$sGiven_z[,,z],2,summary)
    }
  
  
  parm$e$sz = array(,c(data$N, data$K, data$J))
  
  for (z in 1:data$K)
  {  
    parm$e$sz[,z,] = parm$e$sGiven_z[,,z] * parm$e$z[,z]
  }

  
  parm
  
}



fn.Estimate_mgPS <- function(input, data)
{
  
  c(K, J, N, p, cutoff, ASDFlag, ALLstudy, YType) %<-% input

    
  parm = fn.RF_ZFirst(data, svdCutoff=.6)
  
  parm$cutoff = cutoff
  
  list(parm, data)
  
}



fn.ab.to.gamma <- function(alpha_s, beta_z)
{
  gamma_sz = array(rep(beta_z,each=data$J), c(data$J,data$K))
  
  gamma_sz = gamma_sz * alpha_s
  
  as.vector(gamma_sz)
}

fn.sub_gamma.to.ab <- function(sub_gamma_sz)
{
  gamma_sz = c(sub_gamma_sz, (1-sum(sub_gamma_sz)))
  
  gamma_sz = matrix(gamma_sz, byrow = FALSE, ncol=data$K)
  
  alpha_s = rowSums(gamma_sz)
  
  beta_z = colSums(gamma_sz)
  
  list(alpha_s, beta_z)
}


fn.IC <- function(beta_z, alpha_s, data, parm)
{
  
  tmp1.ar = parm$tmp1.ar
  
  constant.mt = array(0, c(data$K,data$J))
  constant.mt = constant.mt + log(beta_z)
  constant.mt = t(t(constant.mt) + log(alpha_s))
  
  wt.v = array(,data$N)
  
  for (s in 1:data$J)
    for (z in 1:data$K)
    {indx.sz = parm$indx.sz.lst[[s,z]]
    wt.v[indx.sz] = tmp1.ar[indx.sz,z,s] + constant.mt[z,s]
    }
  
  maxx = max(wt.v)
  
  wt.v = wt.v - maxx
  
  wt.v = exp(wt.v)
  
  wt.v = wt.v/mean(wt.v)
  
  parm$wt.v = wt.v
  
  parm$ESS = data$N/mean(parm$wt.v^2)
  
  parm$alpha_s = alpha_s
  parm$beta_z = beta_z
  
  parm
}




fn.ESS_IC <- function(sub_gamma_sz, parm)
{
  
  tmp = fn.sub_gamma.to.ab(sub_gamma_sz)
  alpha_s = tmp[[1]]
  beta_z = tmp[[2]]
  
  tmp1.ar = parm$tmp1.ar
  
  constant.mt = array(0, c(data$K,data$J))
  constant.mt = constant.mt + log(beta_z)
  constant.mt = t(t(constant.mt) + log(alpha_s))
  constant.v = as.vector(constant.mt)
 
  tmp2.mt = t(apply(tmp1.ar, 1, as.vector))
  tmp2.mt = t(t(tmp2.mt) + constant.v)
  
  max.v = apply(tmp2.mt, 1, max)
  
  tmp4.mt = tmp2.mt - max.v
  
  tmp5.mt = exp(tmp4.mt)
  
  tmp6.mt = tmp5.mt/ rowSums(tmp5.mt)
  
  wt.mt = tmp6.mt
  
  wt.v = array(,data$N)
  
  for (s in 1:data$J)
    for (z in 1:data$K)
    {indx.sz = parm$indx.sz.lst[[s,z]]
    indx2.sz = (s-1)*data$K +  z
    wt.v[indx.sz] = wt.mt[indx.sz, indx2.sz]
    }
  
  wt.v = wt.v/mean(wt.v)
  
  parm$wt.v = wt.v
  
  parm$ESS = data$N/mean(parm$wt.v^2)
  
  -parm$ESS/data$N
}



fn.ESS_FLEXOR <- function(sub_gamma_sz, parm)
{
  tmp = fn.sub_gamma.to.ab(sub_gamma_sz)
  alpha_s = tmp[[1]]
  beta_z = tmp[[2]]
  
  tmp1.ar = parm$tmp1.ar
  
  constant.mt = array(0, c(data$K,data$J))
  constant.mt = constant.mt + log(beta_z)
  constant.mt = t(t(constant.mt) + log(alpha_s))
  constant.v = as.vector(constant.mt)
  
  tmp2.mt = t(apply(tmp1.ar, 1, "+", 2*constant.mt) )
  
  max.v = apply(tmp2.mt, 1, max)
  
  tmp4.mt = tmp2.mt - max.v
  
  tmp5.mt = exp(tmp4.mt)
  
  tmp6.mt = tmp5.mt/ rowSums(tmp5.mt)
  
  wt.mt = t(t(tmp6.mt) / exp(constant.v))
  
  wt.v = array(,data$N)
  
  for (s in 1:data$J)
    for (z in 1:data$K)
    {indx.sz = parm$indx.sz.lst[[s,z]]
    indx2.sz = (s-1)*data$K +  z
    wt.v[indx.sz] = wt.mt[indx.sz, indx2.sz]
    }
  
  wt.v = wt.v/mean(wt.v)
  
  parm$wt.v = wt.v
  
  parm$ESS = data$N/mean(parm$wt.v^2)
  
  -parm$ESS/data$N
  
  
}


fnWrapper.ESS_FLEXOR <- function(sub_alpha_s, beta_z, parm)
{
  alpha_s = c(sub_alpha_s, (1-sum(sub_alpha_s)))
  parm$gamma_sz = fn.ab.to.gamma(alpha_s, beta_z)
  sub_gamma_sz = head(parm$gamma_sz, -1)
  
  return(fn.ESS_FLEXOR(sub_gamma_sz, parm))
  
}


fn.Omnibus <- function(beta_z, alpha_s, data, parm)
{
  
  tmp1.ar = parm$tmp1.ar
  
  constant.mt = array(0, c(data$K,data$J))
  constant.mt = constant.mt + log(beta_z)
  constant.mt = t(t(constant.mt) + log(as.vector(alpha_s)))
  constant.v = as.vector(constant.mt)
  

  tmp2.mt = t(apply(tmp1.ar, 1, "+", 2*constant.mt) )
  
  max.v = apply(tmp2.mt, 1, max)
  
  tmp4.mt = tmp2.mt - max.v
  
  tmp5.mt = exp(tmp4.mt)

  tmp6.mt = tmp5.mt/ rowSums(tmp5.mt)
  
  wt.mt = t(t(tmp6.mt) / exp(constant.v))
  
  wt.v = array(,data$N)
  
  for (s in 1:data$J)
    for (z in 1:data$K)
    {indx.sz = parm$indx.sz.lst[[s,z]]
    indx2.sz = (s-1)*data$K +  z
    wt.v[indx.sz] = wt.mt[indx.sz, indx2.sz]
    }
  
  wt.v = wt.v/mean(wt.v)
  
  parm$wt.v = wt.v
  
  parm$ESS = data$N/mean(parm$wt.v^2)
  
  parm$alpha_s = alpha_s
  parm$beta_z = beta_z
  
  parm
}



fn.loop <- function(start_beta_z, start_alpha_s, data, parm, FUN, FUN2, tol=1e-3, optim.maxit=2, loop.maxit=50)
{
  
  change = Inf
  count = 0
  
  parm$gamma_sz = fn.ab.to.gamma(start_alpha_s, start_beta_z)

  parm$ESS = 0
  
  while ((change > tol) & (count < loop.maxit))
  {
    old.parm = parm
    sub_gamma_sz = head(old.parm$gamma_sz, -1)
    tmp = optim(sub_gamma_sz, FUN, gr=NULL, old.parm, control= list(maxit=optim.maxit), method = "CG")
    
    sub_gamma_sz = as.numeric(tmp$par)
    tmp2 = fn.sub_gamma.to.ab(sub_gamma_sz)
    parm$alpha_s = tmp2[[1]]
    parm$beta_z = tmp2[[2]]
    parm$gamma_sz = c(sub_gamma_sz, (1-sum(sub_gamma_sz)))
    
    parm$ESS = -tmp$value*data$N
    
    change = abs(parm$ESS-old.parm$ESS)/old.parm$ESS
    count = count + 1
  }
  
  parm$count = count
  parm$change = change 
  
  # get final set of weights
  parm = FUN2(parm$beta_z, parm$alpha_s, data, parm)
  
  parm
}



fn.loop_fixed_beta.z <- function(start_beta_z, start_alpha_s, data, parm, FUN, FUN2, tol=1e-3, optim.maxit=2, loop.maxit=50)
{
  
  change = Inf
  count = 0
  
  parm$alpha_s = start_alpha_s
  parm$beta_z = start_beta_z
  
  # dummy assignment
  parm$ESS = 0
  

  while ((change > tol) & (count < loop.maxit))
  {
    old.parm = parm
    sub_alpha_s = head(parm$alpha_s, -1)
    beta_z = parm$beta_z
    tmp = optim(sub_alpha_s, FUN, gr=NULL, beta_z, old.parm, control= list(maxit=optim.maxit), method = "CG")
    
    sub_alpha_s = as.numeric(tmp$par)
    parm$alpha_s = c(sub_alpha_s, (1-sum(sub_alpha_s)))
    
    parm$ESS = -tmp$value*data$N
    
    change = abs(parm$ESS-old.parm$ESS)/old.parm$ESS
    count = count + 1
  }
  
  parm$count = count
  parm$change = change 
  
  # get final set of weights
  parm = FUN2(parm$beta_z, parm$alpha_s, data, parm)
  
  parm
}


fn.FLEXOR <- function(start_beta_z, start_alpha_s, data, parm)
{

  parm = fn.loop_fixed_beta.z(start_beta_z, start_alpha_s, data, parm, FUN=fnWrapper.ESS_FLEXOR, FUN2=fn.Omnibus)
  
  parm
}

