


flattenData <- function(data)
{
  data$flat = NULL
  
  # data$N by data$p
  data$flat$X = do.call(rbind, data$X)
  
  # data$N by data$p
  data$flat$X.Star = do.call(rbind, data$X.Star)
  
  # data$N 
  data$flat$Z = as.factor(do.call("c", data$Z))
  
  # data$N 
  data$flat$S = as.factor(rep(1:data$J, times=data$N.s))
  
  data
}




formatData <- function(input) 
{
 
  c(K, J, N, p, cutoff, ASDFlag, ALLstudy, YType) %<-% input
 
  data = NULL
  
  data$K = K
  data$J = J
  data$p = p
  data$N = N
  
  data$groupNames = ALLstudy$groupNames

  data$X = data$X.Star = rep(list(NA),data$J)
  
  data$N.s = array(, data$J) 
  
  for (s in 1:data$J)
  {
    indx.s = which(ALLstudy$study==s)
    
    data$X[[s]] = data$X.Star[[s]] = ALLstudy$Xstar[indx.s,]
  
    data$N.s[s] = length(indx.s)
  }
  

  data$N.s = as.vector(data$N.s)
  
  data$Z = rep(list(NA),data$J)
  
  for (s in 1:data$J)
  {
    indx.s = which(ALLstudy$study==s)
    
    data$Z[[s]] = ALLstudy$group[indx.s]
    
    for (rr in 1:data$K)
      {indx.rr.s = which(data$Z[[s]]==rr)
      data$Z[[s]][indx.rr.s] = rr
      }
    
    data$Z[[s]] = as.numeric(data$Z[[s]])
  }
  
  
  data$Z = lapply(data$Z, as.factor)
  
  data$N.sz = array(,c(data$J, data$K))
  for (s in 1:data$J)
    for (z in 1:data$K)
    {data$N.sz[s,z] = sum(data$Z[[s]]==z)
    }
  
  data$N.z = colSums(data$N.sz)
  
 
    data$Y.nameBiomarker = ALLstudy$nameBiomarker
      data$Y = rep(list(NA),data$J)
      
      for (s in 1:data$J)
      {
        indx.s = which(ALLstudy$study==s)
        
        data$Y[[s]] = ALLstudy$genotype.mRNA_expr[indx.s,]
        
      }
    

  
  data = flattenData(data)
  
    data$flat$Y = ALLstudy$genotype.mRNA_expr
  
  data$which.binary = as.numeric(which(unlist(lapply(apply(data$flat$X.Star,2,unique),length))==2))
  
  data

}