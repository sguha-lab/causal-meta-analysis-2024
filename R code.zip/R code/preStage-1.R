

parm$cutoff = input$cutoff
parm$ASDFlag = input$ASDFlag

# N by K by J
tmp.ar = parm$e$sz
tmp.ar[which(tmp.ar>(1-parm$cutoff),arr.ind = TRUE)] = (1-parm$cutoff)
tmp.ar[which(tmp.ar<parm$cutoff,arr.ind = TRUE)] = parm$cutoff

parm$tmp.ar = tmp.ar

parm$tmp1.ar = -log(tmp.ar)

indx.sz.lst = array(list(NA),c(data$J,data$K))

for (s in 1:data$J)
  for (z in 1:data$K)
  {indx.sz.lst[[s,z]] = which((data$flat$S==s)&(data$flat$Z==z))
  }

parm$indx.sz.lst = indx.sz.lst

