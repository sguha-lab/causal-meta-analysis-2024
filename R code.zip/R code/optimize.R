

source("preStage-1.R")

fixed.beta.z.Flag = TRUE
  
  startLabels = c("IC","IGO","Data-driven","IC_optim", "Data-driven_optim")
  num.fixed = length(startLabels)
  
  if (num.random > 0)
  {startLabels = c(startLabels, paste("randomAlpha_optim_",1:num.random,sep=""))
  }
  
  num.starts = num.fixed + num.random 
  
  percentESS.v = array(,num.starts)
  names(percentESS.v) = startLabels
  
  alphaStart.mt = alphaEnd.mt = array(,c(num.starts, input$J))
  betaStart.mt = betaEnd.mt =  array(,c(num.starts, input$K))
  dimnames(alphaStart.mt) = dimnames(alphaEnd.mt) = list(startLabels, NULL)
  dimnames(betaStart.mt) = dimnames(betaEnd.mt) = list(startLabels, NULL)
  
  ########################### 
  
  # IC
  parm.IC = fn.IC(beta_z=rep(1,input$K)/input$K, alpha_s=rep(1,input$J)/input$J, data, parm)
  alphaStart.mt[1,] = alphaEnd.mt[1,] = rep(1,input$J)/input$J
  betaStart.mt[1,] = betaEnd.mt[1,] = rep(1,input$K)/input$K
  percentESS.v[1] = parm.IC$ESS/data$N*100
  
  print(paste("iteration", 1))
  
  # IGO
  parm.IGO = fn.Omnibus(beta_z=rep(1,input$K)/input$K, alpha_s=rep(1,input$J)/input$J, data, parm)
  alphaStart.mt[2,] = alphaEnd.mt[2,] = rep(1,input$J)/input$J
  betaStart.mt[2,] = betaEnd.mt[2,] = rep(1,input$K)/input$K
  percentESS.v[2] = parm.IGO$ESS/data$N*100
  
  print(paste("iteration", 2))
  
  # data-driven 
  parm.dd = fn.Omnibus(beta_z=fixed.beta.z, alpha_s=data$N.s/data$N, data, parm)
  alphaStart.mt[3,] = alphaEnd.mt[3,] = data$N.s/data$N
  betaStart.mt[3,] = betaEnd.mt[3,] = fixed.beta.z
  percentESS.v[3] = parm.dd$ESS/data$N*100
  
  print(paste("iteration", 3))
  
  # FLEXOR w/ IC initialization
 
  alphaStart.mt[4,] = rep(1,input$J)/input$J
  betaStart.mt[4,] = fixed.beta.z
  tmp = try(fn.FLEXOR(start_beta_z=fixed.beta.z, start_alpha_s=rep(1,input$J)/input$J, data, parm.IC))
  if (length(tmp)!=1)
    {parm.IC_optim = tmp
    alphaEnd.mt[4,] = parm.IC_optim$alpha_s
    betaEnd.mt[4,] = parm.IC_optim$beta_z
    percentESS.v[4] = parm.IC_optim$ESS/data$N*100
    }
  if (length(tmp)==1)
    {percentESS.v[4] = 0
    }
  
  print(paste("iteration", 4))
  
  # FLEXOR w/ data-driven initialization
  alphaStart.mt[5,] = data$N.s/data$N
  betaStart.mt[5,] = fixed.beta.z
  tmp = try(fn.FLEXOR(start_beta_z=fixed.beta.z, start_alpha_s=data$N.s/data$N, data, parm))
  if (length(tmp)!=1)
    {parm = tmp
    alphaEnd.mt[5,] = parm$alpha_s
    betaEnd.mt[5,] = parm$beta_z
    percentESS.v[5] = parm$ESS/data$N*100
    }
  if (length(tmp)==1)
    {percentESS.v[5] = 0
    }
  
  print(paste("iteration", 5))
  
  if (num.random>0)
  {
    
    for (cc in (num.fixed+1):num.starts)
    {mass = 50
    alphaStart.mt[cc,] = fn.rdirichlet(alpha=mass*data$N.s/data$N)
    betaStart.mt[cc,] = fixed.beta.z
    #
    tmp = try(fn.FLEXOR(start_beta_z=fixed.beta.z, start_alpha_s=alphaStart.mt[cc,], data, parm), silent = TRUE)
    if (length(tmp)!=1)
      {parm = tmp
      alphaEnd.mt[cc,] = parm$alpha_s
      betaEnd.mt[cc,] = parm$beta_z
      percentESS.v[cc] = parm$ESS/data$N*100
      }
    if (length(tmp)==1)
      {percentESS.v[cc] = 0
      }
    print(paste("iteration", cc))
      
    }
  } # end if (num.random>0)
  

  
  cc.max = 2+which.max(percentESS.v[-(1:2)])
  max(percentESS.v)
  
  
  alphaStart.mt[cc.max,]
  betaStart.mt[cc.max,]
  

  alphaEnd.mt[cc.max,]
  betaEnd.mt[cc.max,]
  
  
  best.parm = fn.FLEXOR(start_beta_z=fixed.beta.z, start_alpha_s=alphaStart.mt[cc.max,], data, parm)
 
  FLEXOR.percentESS = best.parm$ESS/data$N*100
  bestMethod = startLabels[cc.max]
  optim.alpha_s = best.parm$alpha_s
  optim.beta_z = best.parm$beta_z
  

  
  percentESS_methods = c(best.parm$ESS, parm.IGO$ESS, parm.IC$ESS)
  percentESS_methods = percentESS_methods/data$N*100
  names(percentESS_methods) = c("FLEXOR", "IGO", "IC")
  
 
  
  

  